# encoding: utf-8
BUILD_INFO = {"build_date"=>"2016-11-11T22:28:04+00:00", "build_sha"=>"2d8d6263dd09417793f2a0c6d5ee702063b5fada", "build_snapshot"=>false}